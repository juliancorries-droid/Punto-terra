# Punto terra — proyecto Android inicial

Aplicación Android con mapa satelital de Google Maps e importación inicial de puntos desde KML/KMZ.

## Requisito importante
Antes de ejecutar la app, reemplazá `TU_CLAVE_DE_GOOGLE_MAPS` en `app/src/main/AndroidManifest.xml` por una clave de Google Maps Platform con Maps SDK for Android habilitado. La clave puede estar sujeta a facturación y restricciones de Google.

## Compilación
Este proyecto es el código fuente, no un APK ya compilado. Para compilar se necesita Android SDK y Gradle compatible con Android Gradle Plugin 8.7.3 (JDK 17). El ZIP no incluye `gradlew` ni el wrapper JAR.

## Funciones de esta primera base
- Nombre visible: Punto terra.
- Tema verde.
- Mapa satelital.
- Selector de archivos para KML/KMZ.
- Marcadores de puntos importados.

Es una versión inicial y debe probarse en un dispositivo antes de considerarse lista para uso real.
