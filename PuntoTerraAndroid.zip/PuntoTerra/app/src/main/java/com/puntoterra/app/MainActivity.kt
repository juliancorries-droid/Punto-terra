package com.puntoterra.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private var map: GoogleMap? = null
    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importKml(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        val header = TextView(this).apply {
            text = "  ●  Punto terra"
            textSize = 22f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(android.graphics.Color.rgb(35, 77, 53))
            setPadding(16, 18, 16, 18)
        }
        val importButton = Button(this).apply {
            text = "Importar archivo KML / KMZ"
            setOnClickListener { pickFile.launch(arrayOf("application/vnd.google-earth.kml+xml", "application/vnd.google-earth.kmz", "application/zip", "text/xml", "application/octet-stream")) }
        }
        root.addView(header)
        root.addView(importButton)
        val mapHost = LinearLayout(this).apply { id = android.view.View.generateViewId() }
        root.addView(mapHost, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val mapFragment = SupportMapFragment.newInstance()
        supportFragmentManager.beginTransaction().replace(mapHost.id, mapFragment).commit()
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        googleMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        googleMap.uiSettings.isZoomControlsEnabled = true
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(-36.9, -60.3), 5.5f))
    }

    private fun importKml(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("No se pudo abrir el archivo")
            val name = uri.lastPathSegment?.lowercase().orEmpty()
            val kmlBytes = if (name.endsWith(".kmz") || bytes.take(2).toByteArray().contentEquals(byteArrayOf(0x50, 0x4b))) {
                ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                    var found: ByteArray? = null
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (entry.name.endsWith(".kml", true)) { found = zip.readBytes(); break }
                        entry = zip.nextEntry
                    }
                    found ?: throw Exception("El KMZ no contiene un archivo KML")
                }
            } else bytes

            val factory = DocumentBuilderFactory.newInstance()
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true)
            factory.setFeature("http://xml.org/sax/features/external-general-entities", false)
            factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false)
            val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(kmlBytes))
            val placemarks = doc.getElementsByTagNameNS("*", "Placemark")
            var added = 0
            var first: LatLng? = null
            val googleMap = map ?: return
            googleMap.clear()
            for (i in 0 until placemarks.length) {
                val placemark = placemarks.item(i) as? Element ?: continue
                val coords = placemark.getElementsByTagNameNS("*", "coordinates")
                if (coords.length == 0) continue
                val raw = coords.item(0).textContent.trim().substringBefore("\n").substringBefore(" ")
                val parts = raw.split(",")
                if (parts.size < 2) continue
                val lon = parts[0].toDoubleOrNull() ?: continue
                val lat = parts[1].toDoubleOrNull() ?: continue
                val point = LatLng(lat, lon)
                val names = placemark.getElementsByTagNameNS("*", "name")
                val title = if (names.length > 0) names.item(0).textContent else "Punto ${added + 1}"
                googleMap.addMarker(MarkerOptions().position(point).title(title))
                if (first == null) first = point
                added++
            }
            if (first != null) googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(first!!, 14f))
            Toast.makeText(this, "Puntos importados: $added", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo importar: ${e.message ?: "archivo no válido"}", Toast.LENGTH_LONG).show()
        }
    }
}
